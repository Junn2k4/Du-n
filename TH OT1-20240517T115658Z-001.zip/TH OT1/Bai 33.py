class ConTrau:
    def __init__(self, ma_so, nang_suat_cay_ruong, thoi_gian_cay):
        self.ma_so = ma_so
        self.nang_suat_cay_ruong = nang_suat_cay_ruong
        self.thoi_gian_cay = thoi_gian_cay
    def tinh_dien_tich_cay_duoc(self):
        return self.nang_suat_cay_ruong * self.thoi_gian_cay
# Nhập danh sách con trâu
n = int(input("Nhập số lượng con trâu: "))
con_trau_list = []
for i in range(n):
    print(f"Nhập thông tin cho con trâu thứ {i + 1}:")
    ma_so = input("Mã số: ")
    nang_suat_cay_ruong = float(input("Năng suất cày ruộng (m²/giờ): "))
    thoi_gian_cay = float(input("Thời gian cày (giờ): "))
    con_trau = ConTrau(ma_so, nang_suat_cay_ruong, thoi_gian_cay)
    con_trau_list.append(con_trau)
# In danh sách con trâu vừa nhập
print("\nDanh sách con trâu vừa nhập:")
for i, trau in enumerate(con_trau_list):
    print(f"Con trâu {i + 1}: Mã số: {trau.ma_so}, Năng suất cày ruộng: {trau.nang_suat_cay_ruong} m²/giờ, Thời gian cày: {trau.thoi_gian_cay} giờ, Diện tích cày được: {trau.tinh_dien_tich_cay_duoc()} m²")
# Tìm con trâu có sức khỏe dẻo dai nhất và in ra các vị trí nó xuất hiện
suc_khoe_max = max(trau.thoi_gian_cay for trau in con_trau_list)
vi_tri_suc_khoe_max = [i + 1 for i, trau in enumerate(con_trau_list) if trau.thoi_gian_cay == suc_khoe_max]
print(f"\nCon trâu có sức khỏe dẻo dai nhất là {suc_khoe_max} giờ tại các vị trí: {vi_tri_suc_khoe_max}")
# Tính tổng diện tích đàn trâu cày được
tong_dien_tich_cay_duoc = sum(trau.tinh_dien_tich_cay_duoc() for trau in con_trau_list)
print(f"\nTổng diện tích đàn trâu cày được là: {tong_dien_tich_cay_duoc} m².")