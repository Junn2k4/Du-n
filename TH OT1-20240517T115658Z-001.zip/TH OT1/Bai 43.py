class TamGiacVuong:
  def __init__(self, canh_goc_vuong1, canh_goc_vuong2):
    self.canh_goc_vuong1 = canh_goc_vuong1
    self.canh_goc_vuong2 = canh_goc_vuong2

  def tinh_goc(self):
    import math
    goc = math.degrees(math.atan(self.canh_goc_vuong1 / self.canh_goc_vuong2))
    return goc


def nhap_danh_sach_tam_giac(n):
  danh_sach_tam_giac = []
  for i in range(n):
    canh1 = float(input(f"Nhập độ dài cạnh góc vuông 1 của tam giác {i + 1}: "))
    canh2 = float(input(f"Nhập độ dài cạnh góc vuông 2 của tam giác {i + 1}: "))
    tam_giac = TamGiacVuong(canh1, canh2)
    danh_sach_tam_giac.append(tam_giac)
  return danh_sach_tam_giac


def in_danh_sach_tam_giac(danh_sach_tam_giac):
  print("\nDanh sách tam giác vuông:")
  for tam_giac in danh_sach_tam_giac:
    goc = tam_giac.tinh_goc()
    print(
      f"Cạnh góc vuông 1: {tam_giac.canh_goc_vuong1}, Cạnh góc vuông 2: {tam_giac.canh_goc_vuong2}, Góc vuông: {goc:.2f} độ")


def sap_xep_theo_dien_tich(danh_sach_tam_giac):
  return sorted(danh_sach_tam_giac, key=lambda x: x.canh_goc_vuong1 * x.canh_goc_vuong2 / 2, reverse=True)


def tim_tam_giac_dien_tich_lon_nhat(danh_sach_tam_giac):
  tam_giac_lon_nhat = max(danh_sach_tam_giac, key=lambda x: x.canh_goc_vuong1 * x.canh_goc_vuong2 / 2)
  return (tam_giac_lon_nhat.canh_goc_vuong1, tam_giac_lon_nhat.canh_goc_vuong2, tam_giac_lon_nhat.tinh_goc())


n = int(input("Nhập số lượng tam giác vuông: "))
danh_sach_tam_giac = nhap_danh_sach_tam_giac(n)
in_danh_sach_tam_giac(danh_sach_tam_giac)

danh_sach_tam_giac_sap_xep = sap_xep_theo_dien_tich(danh_sach_tam_giac)
print("\nDanh sách sau khi sắp xếp theo diện tích:")
in_danh_sach_tam_giac(danh_sach_tam_giac_sap_xep)

tam_giac_dien_tich_lon_nhat = tim_tam_giac_dien_tich_lon_nhat(danh_sach_tam_giac)
print(f"\nTuple chứa thông tin của tam giác có diện tích lớn nhất: {tam_giac_dien_tich_lon_nhat}")
