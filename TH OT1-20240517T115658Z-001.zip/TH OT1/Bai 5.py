import math

class tam_giac:
  def __init__(self, a, b, c):
    self.a = a
    self.b = b
    self.c = c

  def kiem_tra_tam_giac(self):
    if (self.a + self.b > self.c and self.b + self.c > self.a and self.a + self.c > self.b ):
      return True
  def chu_vi(self):
    return self.a + self.b + self.c
  def dien_tich(self):
    p = round((self.a + self.b + self.c) / 2, 2)
    return round(math.sqrt(p*(p - self.a)*(p - self.b)*(p-self.c)), 2)
  
def nhap_canh(n):
  ds_tam_giac = []
  for i in range(n):
    print(f'Hinh tam giac thu {i+1}: ')
    while True:
      try:
        a = float(input('Nhap canh a: '))
        b = float(input('Nhap canh b: '))
        c = float(input('Nhap canh c: '))
        if (a <= 0 or b <= 0 or c <= 0):
          print('Nhap so duong')
        else:
          tg = tam_giac(a, b, c)
          if (tg.kiem_tra_tam_giac()):
            ds_tam_giac.append(tg)
            break
          else:
            print('3 canh vua nhap khong tao thanh tam giac')
      except ValueError:
        print('Nhap lai')
  return ds_tam_giac

def in_tam_giac(tamgiac):
  if not tamgiac:
    print('Khong co tam giac nao trong danh sach')
  else:
    print('Cac tam giac la:')
    dem = 0
    for i in tamgiac:
      dem += 1
      print(f'{dem}, a = {i.a}, b = {i.b}, c = {i.c}, chuvi = {i.chu_vi()}, dientich = {i.dien_tich()}')

while True:
  try:
    n = int(input('Nhap so hinh tam giac: '))
    lst_tg = nhap_canh(n)
    if (n < 0):
      print('Nhap so duong')
    else:
        in_tam_giac(lst_tg)
        break
  except ValueError:
    print('Nhap lai')