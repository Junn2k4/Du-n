class HocSinh:
    def __init__(self, ten, ma_hs, diem_toan, diem_van, diem_tieng_anh):
        self.ten = ten
        self.ma_hs = ma_hs
        self.diem_toan = diem_toan
        self.diem_van = diem_van
        self.diem_tieng_anh = diem_tieng_anh
    def tinh_tong_diem(self):
        return self.diem_toan + self.diem_van + self.diem_tieng_anh
# Nhập danh sách học sinh
n = int(input("Nhập số lượng học sinh: "))
hoc_sinh_list = []
for i in range(n):
    print(f"Nhập thông tin cho học sinh thứ {i + 1}:")
    ten = input("Tên: ")
    ma_hs = input("Mã học sinh: ")
    diem_toan = float(input("Điểm toán: "))
    diem_van = float(input("Điểm văn: "))
    diem_tieng_anh = float(input("Điểm tiếng Anh: "))
    hoc_sinh = HocSinh(ten, ma_hs, diem_toan, diem_van, diem_tieng_anh)
    hoc_sinh_list.append(hoc_sinh)
# In danh sách học sinh vừa nhập
print("\nDanh sách học sinh vừa nhập:")
for i, hs in enumerate(hoc_sinh_list):
    print(f"Học sinh {i + 1}: {hs.ten}, Mã học sinh: {hs.ma_hs}, Điểm toán: {hs.diem_toan}, Điểm văn: {hs.diem_van}, Điểm tiếng Anh: {hs.diem_tieng_anh}")
# Sắp xếp danh sách học sinh theo thứ tự giảm dần của tổng điểm
hoc_sinh_list.sort(key=lambda x: x.tinh_tong_diem(), reverse=True)
# In danh sách học sinh sau khi sắp xếp
print("\nDanh sách học sinh sau khi sắp xếp theo tổng điểm giảm dần:")
for i, hs in enumerate(hoc_sinh_list):
    print(f"Học sinh {i + 1}: {hs.ten}, Mã học sinh: {hs.ma_hs}, Tổng điểm: {hs.tinh_tong_diem()}")
# Đếm số học sinh có tổng điểm > 15
so_hs_tren_15 = sum(1 for hs in hoc_sinh_list if hs.tinh_tong_diem() > 15)
print(f"\nSố học sinh có tổng điểm > 15 là: {so_hs_tren_15}")
