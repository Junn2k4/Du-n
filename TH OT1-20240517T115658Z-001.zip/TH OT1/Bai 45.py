'''
Tạo 1 class vật nuôi trong 1 trang trại gồm các thuộc tính: tên vật nuôi (gà, lợn, bò…), 
số lượng, lượng thức ăn tiêu thụ của 1 ngày (tính theo kg), số ngày nuôi, và đơn giá 1kg 
thức ăn là 1 tham số mặc định. 
Viết phương thức tính chi phí thức ăn = tổng lượng thức 
ăn* đơn giá. 
- Nhập 1 danh sách các vật nuôi trong trang trại 
- In danh sách vừa nhập  
- Tính tổng chi phí của thức ăn cho cả trang trại
- Đếm số lượng và tạo 1 tuple chứa danh sách các loại vật nuôi có chi phí thức ăn nhỏ nhất trong trang trại.
'''
class vatnuoi:
    def __init__(self,tenvn,sl,tt,songay,dongia=1):
        self.tenvn= tenvn
        self.sl=sl
        self.tt=tt
        self.songay=songay
        self.dongia=dongia
    def chiphi(self):
        return self.songay*self.dongia*self.tt
ds=[]
while True:
    try:
        n=int(input("Nhap danh sach vat nuoi"))
        if n<0:
            print("nhap lai")
        else:
            break
    except ValueError:
        print("Nhap lai!!!")
def nhap(n):
    for i in range(n):
        print(f"Nhap vat nuoi thu {i+1}")
        while True:
            try:
                tenvn=str(input("Nhap ten vat nuoi: "))
                sl=float(input("Nhap so luong: "))
                tt=float(input("Nhap luong thuc an tieu thu: "))
                songay=int(input("Nhap so ngay nuoi: "))
                dongia=float(input("Nhap don gia: "))
                dsach=vatnuoi(tenvn,sl,tt,songay,dongia)
                ds.append(dsach)
                break
            except ValueError:
                print("Nhap lai")
    return ds
def inra(n):
    if not(n):
        print("Khong co danh sach vat nuoi nao ca")
    else:
        print("Danh sach vat nuoi vua nhap la")
        for i,s in enumerate(n):
            print(f"Vat nuoi thu {i+1}:")
            print(f" ten vat nuoi={s.tenvn}, so luong={s.sl}, luong tieu thu ={s.tt} ")
            print(f"so ngay={s.songay},dongia={s.dongia},Chi phi={s.chiphi()}")
def tongchiphi(n):
    tchiphi=sum(chiphi.chiphi() for chiphi in n)
    return tchiphi
def dem(n):
    minchiphi=min(vatnuoi.chiphi() for vatnuoi in n)
    inten=[ (vatnuoi.tenvn, vatnuoi.sl) for vatnuoi in n if vatnuoi.chiphi()==minchiphi ]
    return inten
ds= nhap(n)
inra(ds)
TongChiphi=tongchiphi(ds)
print(f"\nTổng chi phí thức ăn cho cả trang trại: {TongChiphi} đồng")
mincp=dem(ds)
print("danh sách các loại vật nuôi có chi phí thức ăn nhỏ nhat trong trang trai")
for i in mincp:
    print(f"{i[0]}:{i[1]} con")

