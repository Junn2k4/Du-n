class canphong:
  def __init__(self, cd, cr, cc):
    self.cd = cd
    self.cr = cr
    self.cc = cc

  def thetich(self):
    return self.cd * self.cr * self.cc

  def cs(self):
    return self.cd * self.cr * self.cc * 200


def value(n):
  a = {}
  for i in n:
    a = {i.thetich(): i.cs() for i in danhsach}
  return a


def kiemthu(n):
  while 1:
    try:
      gt = float(input(n))
      if gt > 0:
        return gt
      else:
        print('Nhập số lớn hơn 0.')
    except:
      print('Nhập lại số thực.')


danhsach = []
n = int(input('Nhập số lượng căn phòng:'))
for i in range(n):
  print(f'Nhập thông tin căn phòng thứ {i + 1}:')
  a = kiemthu('Nhập chiều dài của căn phòng: ')
  b = kiemthu('Nhập chiều rộng của căn phòng: ')
  c = kiemthu('Nhập chiều cao của căn phòng: ')
  phong = canphong(a, b, c)
  danhsach.append(phong)
print('Danh sách vừa nhập là:')
for i, so in enumerate(danhsach):
  print(f'Căn phòng thứ {i + 1} có cd={so.cd}, cr={so.cr}, cc={so.cc}, công suất={so.cs()}')
ds = value(danhsach)
print(' dic có key là thể tích căn phòng, value là công suất máy điều hòa: ', ds)
socan = 0
for i in danhsach:
  if i.cs() == 9000:
    socan += 1
print(f'=> Có {socan} căn phòng cần lắp ma có cs 9000BTU.')