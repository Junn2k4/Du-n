class DienTro:
  def __init__(self, mau_vong1, mau_vong2, mau_vong3):
    self.mau_vong1 = mau_vong1
    self.mau_vong2 = mau_vong2
    self.mau_vong3 = mau_vong3

  def tinh_gia_tri(self):
    # Dictionary chứa giá trị tương ứng với màu của vòng
    mau_gia_tri = {'đen': 0, 'nâu': 1, 'đỏ': 2, 'cam': 3, 'vàng': 4, 'xanh lá': 5, 'xanh lam': 6, 'xanh dương': 7,
      'tím': 8, 'xám': 9}

    # Tính giá trị của điện trở
    gia_tri = (mau_gia_tri[self.mau_vong1] * 10 + mau_gia_tri[self.mau_vong2]) * (10 ** mau_gia_tri[self.mau_vong3])
    return gia_tri


def in_danh_sach_dien_tro(danh_sach):
  print("Danh sách điện trở:")
  for dien_tro in danh_sach:
    print(
      f"Màu vòng 1: {dien_tro.mau_vong1}, Màu vòng 2: {dien_tro.mau_vong2}, Màu vòng 3: {dien_tro.mau_vong3}, Giá trị: {dien_tro.tinh_gia_tri()}")


def sap_xep_danh_sach(danh_sach):
  return sorted(danh_sach, key=lambda x: x.tinh_gia_tri())


def dem_dien_tro_duoi_1K(danh_sach):
  count = sum(1 for dien_tro in danh_sach if dien_tro.tinh_gia_tri() < 1000)
  return count


def main():
  # Nhập số lượng điện trở
  n = int(input("Nhập số lượng điện trở: "))

  # Nhập danh sách điện trở
  danh_sach_dien_tro = []
  for i in range(n):
    mau_vong1 = input(f"Nhập màu vòng 1 của điện trở thứ {i + 1}: ")
    mau_vong2 = input(f"Nhập màu vòng 2 của điện trở thứ {i + 1}: ")
    mau_vong3 = input(f"Nhập màu vòng 3 của điện trở thứ {i + 1}: ")
    danh_sach_dien_tro.append(DienTro(mau_vong1, mau_vong2, mau_vong3))

  # In danh sách điện trở
  in_danh_sach_dien_tro(danh_sach_dien_tro)

  # Sắp xếp danh sách theo thứ tự tăng dần của trở kháng
  danh_sach_sap_xep = sap_xep_danh_sach(danh_sach_dien_tro)
  print("\nDanh sách điện trở sau khi sắp xếp:")
  in_danh_sach_dien_tro(danh_sach_sap_xep)

  # Đếm số lượng điện trở có giá trị dưới 1K
  count = dem_dien_tro_duoi_1K(danh_sach_dien_tro)
  print(f"\nCó {count} điện trở có giá trị dưới 1K.")


if __name__ == "__main__":
  main()
