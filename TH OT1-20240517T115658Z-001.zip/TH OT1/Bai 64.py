import math

class Demux:
    def __init__(self, ten, so_bit_dau_vao, so_bit_dau_ra):
        self.ten = ten
        self.so_bit_dau_vao = so_bit_dau_vao
        self.so_bit_dau_ra = so_bit_dau_ra

    def so_duong_dieu_khien(self):
        return int(math.log2(self.so_bit_dau_ra / self.so_bit_dau_vao))

# Nhập danh sách mạch DEMUX
n = int(input("Nhập số lượng mạch DEMUX: "))
danh_sach_demux = []
for i in range(n):
    ten = input(f"Nhập tên mạch DEMUX thứ {i+1}: ")
    so_bit_dau_vao = int(input(f"Nhập số bit đầu vào cho {ten}: "))
    so_bit_dau_ra = int(input(f"Nhập số bit đầu ra cho {ten}: "))
    demux = Demux(ten, so_bit_dau_vao, so_bit_dau_ra)
    danh_sach_demux.append(demux)

# In danh sách vừa nhập
print("\nDanh sách mạch DEMUX:")
for demux in danh_sach_demux:
    print(f"{demux.ten}: Số bit đầu vào = {demux.so_bit_dau_vao}, Số bit đầu ra = {demux.so_bit_dau_ra}")

# Sắp xếp danh sách theo thứ tự giảm dần của số bit đầu ra
danh_sach_demux.sort(key=lambda x: x.so_bit_dau_ra, reverse=True)
print("\nDanh sách sau khi sắp xếp:")
for demux in danh_sach_demux:
    print(f"{demux.ten}: Số bit đầu ra = {demux.so_bit_dau_ra}")

# Tạo tuple chứa các mạch DEMUX có nhiều đường điều khiển nhất
max_duong_dieu_khien = max(danh_sach_demux, key=lambda x: x.so_duong_dieu_khien())
print(f"\nMạch DEMUX có nhiều đường điều khiển nhất: {max_duong_dieu_khien.ten} với {max_duong_dieu_khien.so_duong_dieu_khien()} đường điều khiển")
