class songuyen:
    def __init__(self,b):
        self.b= b
    def ktad(self):
        if self.b>0:
            return 1
        else:
            return 0
    def ktxd(self):
        if self.b<10:
            return 0
        else:
            str_b=str(self.b)
            return str_b==str_b[::-1]
    def ktht(self):
        uoc =0
        for i in range(1, self.b):
            if self.b%i==0:
                uoc+=i
        if uoc==self.b:
            return 1
        else: 
            return 0
def nhapso(n):
    lis_so=[]
    lis_duong=[]
    lis_ht=[]
    lis_dx=[]
    for i in range(n):
        print(f"nhap so thu {i+1}")
        while True:
            try:
                a=int(input("nhap so: "))
                so=songuyen(a)
                lis_so.append(so.b)
                if so.ktad()==1:
                    lis_duong.append(so.b)
                if so.ktxd()==1:
                    lis_dx.append(so.b)
                if so.ktht()==1:
                    lis_ht.append(so.b)
                break
            except ValueError:
                print("Nhap lai: ")
    return lis_so,lis_duong,lis_dx,lis_ht
def inso(so,duong,dx,ht):
    if not so:
        print("khong co so nao trong day: ")
    else:
        if not duong:
            print("khong co so duong nao trong day.")
        else:
            print(f"so duong trong day la{duong}")
        if not dx:
            print("Khong co so doi xung. ")
        else:
            print(f"so doi xung lon nhat trong mang la {maxdx(dx)} ")
        if not ht:
            print("khong co so hoan thien.")
        else:
            tong=sum(ht)
            print("tong cac so hoan thien la:",tong)
def maxdx(n):
    maxsdx= n[0]
    for i in range (len(n)):
        if n[i]>maxsdx:
            maxsdx=n[i]
    return maxsdx
while True:
    try:
        n=int(input("Nhap so luong day: "))
        so,duong,dx,ht=nhapso(n)
        if n<0:
            print("nhap lai.")
        else:
            inso(so,duong,dx,ht)
            break
    except ValueError:
        print("Nhap lai. ")

