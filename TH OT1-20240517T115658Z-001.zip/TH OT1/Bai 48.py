class Computer:
  def __init__(self, chip_type, ram_size_mb, hdd_size_gb):
    self.chip_type = chip_type
    self.ram_size_mb = ram_size_mb
    self.hdd_size_gb = hdd_size_gb

  def total_memory(self):
    return self.ram_size_mb + self.hdd_size_gb * 1024

  def __str__(self):
    return f"Chip: {self.chip_type}, RAM: {self.ram_size_mb} MB, HDD: {self.hdd_size_gb} GB"


# Input list of n computers
n = int(input("Enter the number of computers: "))
computers = []
for i in range(n):
  chip_type = input(f"Enter chip type for computer {i + 1}: ")
  ram_size_mb = int(input(f"Enter RAM size (in MB) for computer {i + 1}: "))
  hdd_size_gb = int(input(f"Enter HDD size (in GB) for computer {i + 1}: "))
  computers.append(Computer(chip_type, ram_size_mb, hdd_size_gb))

# Print the list
print("\nList of computers:")
for i, comp in enumerate(computers):
  print(f"{i + 1}. {comp}")

# Separate into two lists: Intel and non-Intel chips
intel_computers = [comp for comp in computers if comp.chip_type.lower() == 'intel']
other_computers = [comp for comp in computers if comp.chip_type.lower() != 'intel']

# Find and display computers with the smallest RAM
min_ram = min(comp.ram_size_mb for comp in computers)
min_ram_computers = [comp for comp in computers if comp.ram_size_mb == min_ram]
print(f"\nComputers with the smallest RAM ({min_ram} MB):")
for comp in min_ram_computers:
  print(f"- {comp}")
