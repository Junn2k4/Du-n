import math

class ptb2:
    def __init__(self, a, b, c):
        self.a = a
        self.b = b
        self.c = c

    def tinhnghiem(self):
        if self.a == 0:   
            x = -self.c / self.b
            return x
        else:
            dental = (self.b)**2 - 4 * self.a * self.c
            if dental == 0:
                x = -self.b / (2 * self.a)
                return x
            if dental > 0:
                x1 = (-self.b + math.sqrt(dental)) / (2 * self.a)
                x2 = (-self.b - math.sqrt(dental)) / (2 * self.a)
                return x1, x2

def nhap(n):
    ds = []
    for i in range(n):
        print(f"Nhap phuong trinh bac 2 thu {i+1}")
        while True:
            try:
                a = float(input("Nhap a: "))
                b = float(input("Nhap b: "))
                c = float(input("Nhap c: "))
                if a == 0 and b == 0 and c == 0:
                    print("Nhap khong hop le, vui long nhap lai")
                    continue
                else:
                    pt = ptb2(a, b, c)
                    ds.append(pt)
                    break
            except ValueError:
                print("Vui long nhap lai")
    return ds

def inra(n):
    nghiem = []
    if not n:
        print("Khong co pt nao")
    else:
        print("Cac pt bac 2 vua nhap la: ")
        for i, s in enumerate(n):
            ngh = s.tinhnghiem()
            nghiem.append(ngh)
            if ngh is None:
                print(f"Nghiem cua phuong trinh bac 2 thu {i+1} la: Khong co nghiem thuc")
            else:
                print(f"Nghiem cua phuong trinh bac 2 thu {i+1} la: a={s.a}, b={s.b}, c={s.c}, nghiem={ngh}")
    print("Tuple nghiem pt la:", tuple(nghiem))
    return tuple(nghiem)
def timnnghiemmax(n):
    s=dict(nghiem)
    return max(s)
danhsach = nhap(2)
nghiem = inra(danhsach)
print("Nghiệm lớn nhất trong các nghiệm của 2 phương trình:", timnnghiemmax(nghiem))
