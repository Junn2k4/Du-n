class CongNhanDaoDuong:
  def __init__(self, ten, cong_suat_dao, thoi_gian_lam_viec, tien_cong_1m_dao):
    self.ten = ten
    self.cong_suat_dao = cong_suat_dao
    self.thoi_gian_lam_viec = thoi_gian_lam_viec
    self.tien_cong_1m_dao = tien_cong_1m_dao

  def tinh_tong_tien_cong(self):
    return self.cong_suat_dao * self.thoi_gian_lam_viec * self.tien_cong_1m_dao


def in_danh_sach_cong_nhan(danh_sach):
  print("Danh sách công nhân:")
  for cong_nhan in danh_sach:
    print(f"Tên: {cong_nhan.ten}, Tiền công: {cong_nhan.tinh_tong_tien_cong()}")


def tim_cong_nhan_tien_cong_cao_nhat(danh_sach):
  if danh_sach:
    cong_nhan_max = max(danh_sach, key=lambda x: x.tinh_tong_tien_cong())
    print(
      f"Công nhân có tiền công cao nhất là {cong_nhan_max.ten} với số tiền là {cong_nhan_max.tinh_tong_tien_cong()}")
  else:
    print("Không có công nhân nào trong danh sách.")


def tinh_tong_tien_luong(danh_sach):
  tong_tien_luong = sum(cong_nhan.tinh_tong_tien_cong() for cong_nhan in danh_sach)
  print(f"Tổng tiền lương của cả danh sách là: {tong_tien_luong}")


def main():
  # Nhập số lượng công nhân
  n = int(input("Nhập số lượng công nhân: "))

  # Nhập danh sách công nhân
  danh_sach_cong_nhan = []
  for i in range(n):
    ten = input(f"Nhập tên công nhân thứ {i + 1}: ")
    cong_suat_dao = float(input(f"Nhập công suất đào của công nhân {ten} (mét/giờ): "))
    thoi_gian_lam_viec = float(input(f"Nhập thời gian làm việc của công nhân {ten} (giờ): "))
    tien_cong_1m_dao = float(input(f"Nhập tiền công cho 1 mét đào của công nhân {ten}: "))
    danh_sach_cong_nhan.append(CongNhanDaoDuong(ten, cong_suat_dao, thoi_gian_lam_viec, tien_cong_1m_dao))

  # In danh sách công nhân
  in_danh_sach_cong_nhan(danh_sach_cong_nhan)

  # Tìm công nhân có tiền công cao nhất
  tim_cong_nhan_tien_cong_cao_nhat(danh_sach_cong_nhan)

  # Tính tổng tiền lương của cả danh sách
  tinh_tong_tien_luong(danh_sach_cong_nhan)


if __name__ == "__main__":
  main()
