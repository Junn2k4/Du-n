class tugiac:
    def __init__(self,a,b,c,d):
        self.a=a
        self.b=b
        self.c=c
        self.d=d
    def chuvi(self):
        return self.a+self.b+self.c+self.d
    def canhmax(self):
        return max(self.a,self.b,self.c,self.d)
while True:
    try:
        n=int(input("Nhap so luong tu giac."))
        if n<0:
            print("Nhap so duong: ")
        else:
            break
    except ValueError:
        print("nhap lai!!!")
def nhapcanh(n):
    dsach=[]
    for i in range(n):
        print(f"nhap tu giac thu {i+1}")
        while True:
            try:
                a=float(input("nhap canh thu 1: "))
                b=float(input("nhap canh thu 2: "))
                c=float(input("nhap canh thu 3: "))
                d=float(input("nhap canh thu 4: "))
                if (a<=0 or b<=0 or c<=0 or d<=0):
                    print("Nhap cac so duong")
                else:
                    tg=tugiac(a,b,c,d)
                    dsach.append(tg)
                    break
            except ValueError:
                print("nhap lai. ")
    return dsach
def intugiac(ds):
    if not ds:
        print("khong co danh sach nao")
    else:
        print("cac hinh tu giac la:")
        dem=0
        for i in ds:
            dem+=1
            print(f"hinh tu giac {dem} , a={i.a},b={i.b},c={i.c},d={i.d}, chuvi={i.chuvi()},canhmax={i.canhmax()}")
def cvmin(ds):
    a=ds[0].chuvi()
    for i in ds:
        if i.chuvi()<a:
            a=i.chuvi()
    return a
def timhinh(ds):
    hinh=[]
    for i,s in enumerate(ds):
        if s.chuvi()==cvmin(ds):
            hinh.append(i+1)
    return hinh
ds=nhapcanh(n)
intugiac(ds)
print("chu vi nho nhat la: ",cvmin(ds))
print("hinh co chu vi nho nhat la: ",timhinh(ds))