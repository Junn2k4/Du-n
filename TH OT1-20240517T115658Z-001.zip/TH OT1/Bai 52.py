class SinhVien:
  def __init__(self, ten, diem_bao_cao, diem_thiet_ke_pc, diem_thiet_ke_pm, diem_thuyet_trinh):
    self.ten = ten
    self.diem_bao_cao = diem_bao_cao
    self.diem_thiet_ke_pc = diem_thiet_ke_pc
    self.diem_thiet_ke_pm = diem_thiet_ke_pm
    self.diem_thuyet_trinh = diem_thuyet_trinh

  def tinh_tong_diem(self):
    return self.diem_bao_cao + self.diem_thiet_ke_pc + self.diem_thiet_ke_pm + self.diem_thuyet_trinh


def in_danh_sach_sinh_vien(danh_sach):
  print("Danh sách sinh viên:")
  for sinh_vien in danh_sach:
    print(
      f"Tên: {sinh_vien.ten}, Điểm báo cáo: {sinh_vien.diem_bao_cao}, Điểm thiết kế phần cứng: {sinh_vien.diem_thiet_ke_pc}, Điểm thiết kế phần mềm: {sinh_vien.diem_thiet_ke_pm}, Điểm thuyết trình: {sinh_vien.diem_thuyet_trinh}")


def sap_xep_danh_sach(danh_sach):
  return sorted(danh_sach, key=lambda x: x.tinh_tong_diem(), reverse=True)


def tach_danh_sach(danh_sach):
  danh_sach_pm = [sv for sv in danh_sach if sv.diem_thiet_ke_pm > sv.diem_thiet_ke_pc]
  danh_sach_pc = [sv for sv in danh_sach if sv.diem_thiet_ke_pm < sv.diem_thiet_ke_pc]
  return danh_sach_pm, danh_sach_pc


def main():
  # Nhập số lượng sinh viên
  n = int(input("Nhập số lượng sinh viên: "))

  # Nhập danh sách sinh viên
  danh_sach_sinh_vien = []
  for i in range(n):
    ten = input(f"Nhập tên sinh viên thứ {i + 1}: ")
    diem_bao_cao = float(input(f"Nhập điểm báo cáo của sinh viên {ten}: "))
    diem_thiet_ke_pc = float(input(f"Nhập điểm thiết kế phần cứng của sinh viên {ten}: "))
    diem_thiet_ke_pm = float(input(f"Nhập điểm thiết kế phần mềm của sinh viên {ten}: "))
    diem_thuyet_trinh = float(input(f"Nhập điểm thuyết trình của sinh viên {ten}: "))
    danh_sach_sinh_vien.append(SinhVien(ten, diem_bao_cao, diem_thiet_ke_pc, diem_thiet_ke_pm, diem_thuyet_trinh))

  # In danh sách sinh viên
  in_danh_sach_sinh_vien(danh_sach_sinh_vien)

  # Sắp xếp danh sách sinh viên theo thứ tự giảm dần của tổng điểm
  danh_sach_sap_xep = sap_xep_danh_sach(danh_sach_sinh_vien)
  print("\nDanh sách sinh viên sau khi sắp xếp:")
  in_danh_sach_sinh_vien(danh_sach_sap_xep)

  # Tách thành 2 danh sách: 1 danh sách chứa các sinh viên có khả năng thiết kế phần mềm tốt hơn phần cứng và 1 danh sách chứa các sinh viên có khả năng thiết kế phần cứng tốt hơn phần mềm
  danh_sach_pm, danh_sach_pc = tach_danh_sach(danh_sach_sap_xep)
  print("\nDanh sách sinh viên có khả năng thiết kế phần mềm tốt hơn phần cứng:")
  in_danh_sach_sinh_vien(danh_sach_pm)
  print("\nDanh sách sinh viên có khả năng thiết kế phần cứng tốt hơn phần mềm:")
  in_danh_sach_sinh_vien(danh_sach_pc)


if __name__ == "__main__":
  main()
