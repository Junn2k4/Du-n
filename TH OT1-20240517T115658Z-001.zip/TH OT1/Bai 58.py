class BeCa:
  def __init__(self, loai_ca, don_gia, san_luong, chi_phi_von):
    self.loai_ca = loai_ca
    self.don_gia = don_gia
    self.san_luong = san_luong
    self.chi_phi_von = chi_phi_von

  def tinh_so_tien_cong(self):
    return self.don_gia * self.san_luong - self.chi_phi_von


def in_danh_sach_be_ca(danh_sach):
  print("Danh sách bè cá:")
  for be_ca in danh_sach:
    print(
      f"Loại cá: {be_ca.loai_ca}, Đơn giá cho 1kg: {be_ca.don_gia}, Sản lượng thu được: {be_ca.san_luong}kg, Chi phí vốn ban đầu: {be_ca.chi_phi_von}đ")


def tao_dictionary_tien_cong(danh_sach):
  dictionary = {}
  for be_ca in danh_sach:
    tien_cong = be_ca.tinh_so_tien_cong()
    dictionary[be_ca.loai_ca] = tien_cong
  return dictionary


def tinh_tong_tien_cong(danh_sach):
  tong_tien_cong = sum(be_ca.tinh_so_tien_cong() for be_ca in danh_sach)
  return tong_tien_cong


def main():
  # Nhập số lượng bè cá
  n = int(input("Nhập số lượng bè cá: "))

  # Nhập danh sách bè cá
  danh_sach_be_ca = []
  for i in range(n):
    loai_ca = input(f"Nhập loại cá của bè cá thứ {i + 1}: ")
    don_gia = float(input(f"Nhập đơn giá cho 1kg của loại cá {loai_ca}: "))
    san_luong = float(input(f"Nhập sản lượng thu được của loại cá {loai_ca} (kg): "))
    chi_phi_von = float(input(f"Nhập chi phí vốn ban đầu của loại cá {loai_ca}: "))
    danh_sach_be_ca.append(BeCa(loai_ca, don_gia, san_luong, chi_phi_von))

  # In danh sách bè cá
  in_danh_sach_be_ca(danh_sach_be_ca)

  # Tạo dictionary có key là loại cá và value là tiền công thu được sau 1 lần thu hoạch
  dictionary_tien_cong = tao_dictionary_tien_cong(danh_sach_be_ca)
  print("\nDictionary tiền công thu được sau 1 lần thu hoạch:")
  print(dictionary_tien_cong)

  # Tính tổng số tiền công thu được trong danh sách
  tong_tien_cong = tinh_tong_tien_cong(danh_sach_be_ca)
  print(f"\nTổng số tiền công thu được trong danh sách: {tong_tien_cong}đ")


if __name__ == "__main__":
  main()
