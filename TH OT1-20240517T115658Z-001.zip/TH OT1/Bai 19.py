import math
class HT:
    def __init__(self,r):
        self.r=r
    def chuvi(self):
        return 2*math.pi*self.r
    def dientich(self):
        return math.pi*self.r**2
while 1:
    try:
        n=int(input("Nhap so hinh tron: "))
        if n<0:
            print("Nhap lai: ")
        else:
            break
    except ValueError:
        print("Nhap lai.")
def nhap(n):
    ds=[]
    for i in range(n):
        print(f"Nhap ban kinh hinh tron thu {i+1} la:")
        while 1:
            try:
                r=float(input("Nhap do dai ban kinh"))
                if r<0:
                    print("Moi nhap lai")
                else:
                    hto=HT(r)
                    ds.append(hto)
                    break
            except ValueError:
                print("Nhap lai")
    return ds
def inra(n):
    if not n:
        print("Nhap lai")
    else:
        for i,s in enumerate(n):
            print(f"Hinh tron thu {i+1}: ")
            print(f" Ban kinh = {s.r}, chu vi={s.chuvi()}, dien tich ={s.dientich()}")
def tongdt(n):
    tong=0
    for i in n:
        tong+=i.dientich()
    return tong
def bkmin(n):
    a=n[0].r
    for i in n:
        if i.r<a:
            a=i.r
    return a
def timhinh(n):
    hinh=[]
    for i,s in enumerate(n):
        if s.r==bkmin(n):
            hinh.append(i+1)
    return hinh
dsach=nhap(n)
inra(dsach)
print("tong dien tich cac hinh: ", tongdt(dsach))
print("Hinh nho hon la hinh: ", timhinh(dsach))

