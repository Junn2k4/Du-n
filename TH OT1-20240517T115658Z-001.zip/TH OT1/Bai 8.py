class HHCN:
    def __init__(self,a,b,c):
        self.a = a
        self.b = b
        self.c = c
    def sxq(self):
        return (self.a+self.b)*2*self.c
    def V(self):
        return self.a*self.b*self.c

def nhap(n):
    f=[]
    d=1
    for i in range(n):
        print(f'Nhập hình hộp chữ nhật thứ {d}:')
        while 1:
            try:
                a=float(input('Nhập cạnh a: '))
                b=float(input('Nhập cạnh b: '))
                c=float(input('Nhập chiều cao c: '))
                if (a<=0) or (b<=0) or (c<=0):
                    print('Nhập lại!')
                else:
                    break
            except ValueError:
                print('Nhập lại!')
        f.append(HHCN(a,b,c))
        d+=1
    return f

def tong(ds):
    t=0
    for i in ds:
        t+=i.V()
    return t
def vmax(ds):
    m=0
    d=1
    for i in ds:
        if i.V()>m:
            m=i.V()
            v=d
        d+=1
    return v

def indl(ds):
    d=1
    for i in ds:
        print(f'Hình hộp chữ nhật thứ {d}:')
        print(f' Diện tích xung quanh: {i.sxq()}')
        print(f' Thể tích: {i.V()}')
        d+=1
    print(f'Tổng diện tích: {tong(ds)}')
    print(f'Hình thứ {vmax(ds)} có thể tích lớn nhất')

while 1:
    try:
        n=int(input('Nhập số lượng hinh hộp chữ nhật: '))
        if n<1:
            print('Nhập lại!')
        else:
            break
    except ValueError:
        print('Nhập lại!')

ds=nhap(n)
indl(ds)
