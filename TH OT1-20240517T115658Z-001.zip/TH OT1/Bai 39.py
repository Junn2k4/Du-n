class HangHoa:
  def __init__(self, ten, gia_thanh, so_luong):
    self.ten = ten
    self.gia_thanh = gia_thanh
    self.so_luong = so_luong

  def tinh_tong_tien(self):
    return self.gia_thanh * self.so_luong


def in_danh_sach_hang_hoa(danh_sach):
  print("Danh sách hàng hóa:")
  for hang_hoa in danh_sach:
    print(f"Tên hàng: {hang_hoa.ten}, Giá thành: {hang_hoa.gia_thanh}, Số lượng: {hang_hoa.so_luong}")


def sap_xep_danh_sach(danh_sach):
  return sorted(danh_sach, key=lambda x: x.gia_thanh)


def tao_dictionary_hang_hoa(danh_sach):
  dictionary = {}
  for hang_hoa in danh_sach:
    dictionary[hang_hoa.ten] = hang_hoa.tinh_tong_tien()
  return dictionary


def main():
  # Nhập số lượng hàng hóa
  n = int(input("Nhập số lượng hàng hóa: "))

  # Nhập danh sách hàng hóa
  danh_sach_hang_hoa = []
  for i in range(n):
    ten = input(f"Nhập tên hàng hóa thứ {i + 1}: ")
    gia_thanh = float(input(f"Nhập giá thành của hàng hóa {ten}: "))
    so_luong = int(input(f"Nhập số lượng của hàng hóa {ten}: "))
    danh_sach_hang_hoa.append(HangHoa(ten, gia_thanh, so_luong))

  # In danh sách hàng hóa
  in_danh_sach_hang_hoa(danh_sach_hang_hoa)

  # Sắp xếp danh sách theo thứ tự tăng dần của tiền hàng
  danh_sach_sap_xep = sap_xep_danh_sach(danh_sach_hang_hoa)
  print("\nDanh sách hàng hóa sau khi sắp xếp:")
  in_danh_sach_hang_hoa(danh_sach_sap_xep)

  # Tạo dictionary có key là tên hàng và value là tiền hàng
  dictionary_hang_hoa = tao_dictionary_hang_hoa(danh_sach_hang_hoa)
  print("\nDictionary hàng hóa:")
  print(dictionary_hang_hoa)

