class ConOng:
    def __init__(self, loai_ong, van_toc_bay, thoi_gian_bay):
        self.loai_ong = loai_ong
        self.van_toc_bay = van_toc_bay
        self.thoi_gian_bay = thoi_gian_bay
    def tinh_quang_duong_bay(self):
        return self.van_toc_bay * self.thoi_gian_bay
# Nhập danh sách con ong
n = int(input("Nhập số lượng con ong: "))
con_ong_list = []
for i in range(n):
    print(f"Nhập thông tin cho con ong thứ {i + 1}:")
    loai_ong = input("Loại ong: ")
    van_toc_bay = float(input("Vận tốc bay (m/s): "))
    thoi_gian_bay = float(input("Thời gian bay (s): "))
    con_ong = ConOng(loai_ong, van_toc_bay, thoi_gian_bay)
    con_ong_list.append(con_ong)
# In danh sách con ong vừa nhập
print("\nDanh sách con ong vừa nhập:")
for i, ong in enumerate(con_ong_list):
    print(f"Con ong {i + 1}: Loại ong: {ong.loai_ong}, Vận tốc bay: {ong.van_toc_bay} m/s, Thời gian bay: {ong.thoi_gian_bay} s, Quãng đường bay: {ong.tinh_quang_duong_bay()} m")
# Tìm con ong có vận tốc nhanh nhất và in ra các vị trí con ong đó xuất hiện
van_toc_nhanh_nhat = max(ong.van_toc_bay for ong in con_ong_list)
vi_tri_van_toc_nhanh_nhat = [i + 1 for i, ong in enumerate(con_ong_list) if ong.van_toc_bay == van_toc_nhanh_nhat]
print(f"\nCon ong có vận tốc nhanh nhất là {van_toc_nhanh_nhat} m/s tại các vị trí: {vi_tri_van_toc_nhanh_nhat}")
# Đếm số con ong bay được quãng đường dài nhất và quãng đường đó
quang_duong_dai_nhat = max(ong.tinh_quang_duong_bay() for ong in con_ong_list)
so_ong_quang_duong_dai_nhat = sum(1 for ong in con_ong_list if ong.tinh_quang_duong_bay() == quang_duong_dai_nhat)
print(f"\nTrong danh sách có {so_ong_quang_duong_dai_nhat} con ong bay được quãng đường dài nhất là {quang_duong_dai_nhat} m.")

