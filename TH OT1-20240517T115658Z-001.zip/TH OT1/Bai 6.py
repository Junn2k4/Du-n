import math

class tam_giac_vuong:
  def __init__(self, a, b):
    self.a = a
    self.b = b
  
  def canh_huyen(self):
    return round(math.sqrt(self.a**2 + self.b**2), 2)
  def dien_tich(self):
    return 1/2*self.a*self.b
  def chu_vi(self):
    return self.a + self.b + round(math.sqrt(self.a**2 + self.b**2), 2)
  
def nhap_canh(n):
  lst_htg = []
  lst_canh_huyen = []
  for i in range(n):
    print(f'Nhap tam giac vuong thu {i+1}: ')
    while True:
      try:
        a = float(input('Nhap canh goc vuong thu nhat: '))
        b = float(input('Nhap canh goc vuong thu hai: '))
        if a <= 0 or b <= 0:
          print('Nhap so duong')
        else:
          htg = tam_giac_vuong(a, b)
          lst_htg.append(htg)
          lst_canh_huyen.append(htg.canh_huyen())
          break
      except ValueError:
        print('Nhap lai')
  return lst_htg, lst_canh_huyen

def canh_huyen_max(arr, n):
  max = arr[0]
  for i in range(1, n):
    if arr[i] > max:
      max = arr[i]
  return max

def in_tg(tamgiac, canhhuyen):
  if not tamgiac:
    print('Khong co tam giac trong danh sach')
  else:
    print('Cac hinh tam giac la: ')
    dem = 0
    for i in tamgiac:
      dem += 1
      print(f'{dem}, canh1 = {i.a}, canh2 = {i.b}, chuvi = {i.chu_vi()}, dientich = {i.dien_tich()}, canhhuyen = {i.canh_huyen()}')
    print(f'Hinh tam giac so {canhhuyen.index(canh_huyen_max(canhhuyen, len(canhhuyen))) + 1} co canh huyen lon nhat')

while True:
  try:
    n = int(input('Nhap so tam giac: '))
    lst_tg, lst_canh_huyen = nhap_canh(n)
    if (n<0):
      print('Nhap so duong')
    else:
      in_tg(lst_tg, lst_canh_huyen)
      break
  except ValueError:
    print('Nhap lai')