class duongthang:
    def __init__(self, x1,y1,x2,y2):
        self.x1=x1
        self.y1=y1
        self.x2=x2
        self.y2=y2
    def dodai(self):
        return round(((self.x2-self.x1)**2+(self.y2-self.y1)**2)**0.5,2)
def nhapvao():
    ds=[]
    for i in range(3):
        print(f"Nhap doan thang thu {i+1}: ")
        while True:
            try:
                x1=float(input("nhap toa do x diem dau: "))
                y1=float(input("nhap toa do y diem dau: ")) 
                x2=float(input("nhap toa do x diem cuoi: "))
                y2=float(input("nhap toa do y diem cuoi: "))
                td=duongthang(x1,y1,x2,y2)
                ds.append(td)
                break
            except ValueError:
                print("nhap lai")
    return ds
def inra(n):
    if not n:
        print("nhap lai: ")
    else:
        print("Cac doan thang vua nhap la: ")
        dem=0
        for i in n:
            dem+=1
            print(f"Doan thang thu {dem+1}: dodai={i.dodai()}")
def kttamgiac(n):
    if (n[0].x1==n[1].x1 and n[0].x2==n[1].x2 and n[0].y1==n[1].y1 and n[0].y2==n[1].y2 ):
        return False
    elif (n[1].x1==n[2].x1 and n[1].x2==n[2].x2 and n[1].y1==n[2].y1 and n[1].y2==n[2].y2 ):
        return False
    elif (n[0].x1==n[2].x1 and n[0].x2==n[2].x2 and n[0].y1==n[2].y1 and n[0].y2==n[2].y2 ):
        return False
    elif (n[0].dodai() + n[1].dodai() > n[2].dodai() and \
        n[0].dodai() + n[2].dodai() > n[1].dodai() and \
        n[1].dodai() + n[2].dodai() > n[0].dodai()):
        return True
    else:
        return False
def dodai3doan(n):
    dodai3 =[doanthang.dodai() for doanthang in n]
    return dodai3
def doanthangmax(n):
    a=n[0].dodai()
    for i in n:
        if i.dodai()>a:
            a=i.dodai()
    return a
def timdt(n):
    hinh=[]
    for i,s in enumerate(n):
        if s.dodai()==doanthangmax(n):
            hinh.append(i+1)
    return hinh
ds=nhapvao()
inra(ds)
print("do dai 3 doan thang la: ",dodai3doan(ds))
kttg=kttamgiac(ds)
if kttg == True:
    print("3 doan thang vua nhap co the tao thanh tam giac")
else:
    print("3 doan thang vua nhap khong the tao thanh tam giac")
print("doan thang co do dai dai nhat la: ", timdt(ds))