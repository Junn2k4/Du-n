class songuyen:
  def __init__(self,n):
    self.n = n

  def chanle(self):
    if self.n % 2 == 0:
      return True

    else:
      return False

  def soCP(self):
    i = 0

    while (i * i <= self.n):
      if i * i == self.n:
        return True
      i = i + 1
    else:
        return False

  def dao(self):
    if self.n < 0:
      return "ko có số đảo"

    elif self.n == 0:
      return 0
    else:
      soDaoNguoc = 0
      while (self.n > 0):
        chuSoCuoi = self.n % 10
        soDaoNguoc = soDaoNguoc * 10 + chuSoCuoi
        self.n = self.n // 10
      return soDaoNguoc

ds = []
for i in range(3):
  n = int(input("Số nguyên %d: " % (i + 1)))
  ob = songuyen(n)
  ds.append(ob)
for i in range(3):
  print("Số đảo của số thứ", i + 1, "là: ", songuyen(ds[i].n).dao())
tong = 0
for i in range(3):
    if ds[i].chanle() == False:
      tong = tong + ds[i].n
if tong != 0:
    print("Tổng các số lẻ là: ", tong)
else:
    print("Ko có số lẻ.")
cp = []
for i in range(3):
    if ds[i].soCP() == True:
      cp.append(ds[i].n)
if len(cp) != 0:
    print("Số cp max là: ", max(cp))
else:
    print("Ko có số cp")