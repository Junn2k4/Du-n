class songuyen:
    def __init__(self, a):
        self.a=a
    def chan(self):
        if self.a%2==0:
            return "chẵn"
        else :
            return "lẻ"
    def ktsnt(self):
        uoc = 0
        for i in range(2, self.a + 1):
         if self.a % i == 0:
             uoc += 1
        if uoc == 1:
         return True
        else:
         return False
    def ktcp(self):
        for i in range(1, self.a + 1):
            if i**2 == self.a:
                return True
                break
        return False
def nhap_so(n):
  lst_so = []
  lst_so_chan = []
  lst_chinh_phuong = []
  lst_nguyen_to =[]
  for i in range(n):
    print(f'So thu {i+1}: ')
    while True:
      try:
        a = int(input('Nhap so: '))
        so = songuyen(a)
        lst_so.append(so)
        if so.chan() == 'chẵn':
          lst_so_chan.append(so.a)
        if so.ktcp():
          lst_chinh_phuong.append(so.a)
        if so.ktsnt():
          lst_nguyen_to.append(so.a)
        break
      except ValueError:
        print('nhap lai')
  return lst_so, lst_so_chan, lst_chinh_phuong, lst_nguyen_to     

def in_so(day_so, so_chan, chinh_phuong, nguyen_to):
  if not day_so:
    print('Khong co so nao trong day')
  else:
        if not so_chan:
            print('Khong co so chan trong day')
        else:
            print(f'Cac so chan la: {so_chan}')
        if not chinh_phuong:
            print('Khong co so chinh phuong trong day')
        else:
            tong = 0
        for i in chinh_phuong:
             tong += i
        print(f'Tong cac so chinh phuong la: {tong}')
        if not nguyen_to:
            print('Khong co so nguyen to')
        else:
            print(f'So nguyen to lon nhat la: {max_nguyen_to(nguyen_to)}')

def max_nguyen_to(nguyento):
  max = nguyento[0]
  for i in nguyento:
    if i > max:
      max = i
  return max

while True:
  try:
    n = int(input('Nhap so chu so: '))
    day_so, so_chan, chinh_phuong, nguyen_to = nhap_so(n)
    if (n<0):
      print('nhap lai')
    else:
      in_so(day_so, so_chan, chinh_phuong, nguyen_to)
      break
  except ValueError:
    print('Nhap lai')

    
