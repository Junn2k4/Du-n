class songuyen:
  def __init__(self,n):
    self.n = n
  def chanle(self):
    if self.n%2==0:
      return True
    else:
      return False
  def soCP(self):
    i=0
    while(i*i<=self.n):
      if i*i==self.n:
        return True
      i=i+1
    else:
      return False
  def dao(self):
    if self.n<0:
      return "ko có số đảo"
    elif self.n==0:
      return 0
    else:
      sodao=0
      while(self.n>0):
        chusocuoi=self.n%10
        sodao=sodao*10 + chusocuoi
        self.n=self.n//10
      return sodao
ds=[]
for i in range(3):
  n=int(input("Số nguyên thứ %d: " %(i+1)))
  ob=songuyen(n)
  ds.append(ob)
  dic={}
for i in range(3):
  dic[ds[i].n]=songuyen(ds[i].n).dao()
print(dic)
tong=0
for i in range(3):
  tong=tong+songuyen(ds[i].n).dao()
  if tong!=0:
    print("Tổng các số đảo là ",tong)
  else:
    print("Ko có số đảo")
cp=[]
for i in range(3):
    if ds[i].soCP()==True:
      cp.append(ds[i].n)
if len(cp)!=0:
  print("Số cp min là: ",min(cp))
else:
  print("Ko có số cp")