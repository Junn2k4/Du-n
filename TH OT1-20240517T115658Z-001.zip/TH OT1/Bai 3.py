import math

class hinh_vuong:
  def __init__(self, a):
    self.a = a

  def chu_vi(self):
    return (self.a)*4
  def dien_tich(self):
    return (self.a)**2
  def duong_cheo(self):
    return (self.a)*math.sqrt(2)
  
def nhap_canh(n):
  ds_hinh_vuong = []
  ds_duong_cheo = []
  for i in range(n):
    print(f'Hinh vuong thu {i+1}: ')
    while True:
      try:
        a = float(input('Nhap canh hinh vuong: '))
        if (a <= 0):
          print('Nhap so duong')
        else:
          hv = hinh_vuong(a)
          ds_hinh_vuong.append(hv)
          ds_duong_cheo.append(hv.duong_cheo())
          break
      except ValueError:
        print('Nhap lai')
  return ds_hinh_vuong, ds_duong_cheo

def duong_cheo_max(arr, n):
  max = arr[0]
  for i in range(1, n):
    if arr[i] > max:
      max = arr[i]
  return max

def in_hinh_vuong(hinhvuong, duongcheo):
  if not hinhvuong:
    print('Khong co hinh vuong trong danh sach')
  else:
    print('Cac hinh vuong la:')
    dem = 0
    for i in hinhvuong:
      dem += 1
      print(f'{dem}, canh = {i.a}, chuvi = {i.chu_vi()}, dientich = {i.dien_tich()}, duongcheo = {i.duong_cheo()}')
    print(f'Duong cheo lon nhat la: {duong_cheo_max(duongcheo, len(duongcheo))}')

while True:
  try:
    n = int(input('Nhap so hinh vuong: '))
    lst_hv, lst_duong_cheo = nhap_canh(n)
    if (n < 0):
      print('Nhap so duong')
    else:
      in_hinh_vuong(lst_hv, lst_duong_cheo)
      break
  except ValueError:
    print('Nhap lai')