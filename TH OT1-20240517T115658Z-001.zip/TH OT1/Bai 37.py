class MayBomNuoc:
  def __init__(self, loai_may_bom, cong_suat, thoi_gian_hoat_dong):
    self.loai_may_bom = loai_may_bom
    self.cong_suat = cong_suat
    self.thoi_gian_hoat_dong = thoi_gian_hoat_dong

  def tinh_nang_luong_tieu_thu(self):
    return self.cong_suat * self.thoi_gian_hoat_dong


def nhap_danh_sach_may_bom(n):
  danh_sach_may_bom = []
  for i in range(n):
    loai_may_bom = input(f"Nhập loại máy bơm {i + 1}: ")
    cong_suat = float(input(f"Nhập công suất (W/h) của máy bơm {i + 1}: "))
    thoi_gian_hoat_dong = float(input(f"Nhập thời gian hoạt động (giờ) của máy bơm {i + 1}: "))
    may_bom = MayBomNuoc(loai_may_bom, cong_suat, thoi_gian_hoat_dong)
    danh_sach_may_bom.append(may_bom)
  return danh_sach_may_bom


def in_danh_sach_may_bom(danh_sach_may_bom):
  print("\nDanh sách máy bơm:")
  for may_bom in danh_sach_may_bom:
    print(
      f"Loại máy bơm: {may_bom.loai_may_bom}, Công suất: {may_bom.cong_suat} W/h, Năng lượng tiêu thụ: {may_bom.tinh_nang_luong_tieu_thu()} Wh")


def sap_xep_theo_cong_suat(danh_sach_may_bom):
  return sorted(danh_sach_may_bom, key=lambda x: x.cong_suat, reverse=True)


def tinh_tong_nang_luong_tieu_thu(danh_sach_may_bom):
  return sum(may_bom.tinh_nang_luong_tieu_thu() for may_bom in danh_sach_may_bom)


n = int(input("Nhập số lượng máy bơm: "))
danh_sach_may_bom = nhap_danh_sach_may_bom(n)
in_danh_sach_may_bom(danh_sach_may_bom)
danh_sach_may_bom_sap_xep = sap_xep_theo_cong_suat(danh_sach_may_bom)
print("\nDanh sách sau khi sắp xếp theo công suất:")
in_danh_sach_may_bom(danh_sach_may_bom_sap_xep)
tong_nang_luong_tieu_thu = tinh_tong_nang_luong_tieu_thu(danh_sach_may_bom)
print(f"\nTổng năng lượng tiêu thụ của {n} máy bơm là: {tong_nang_luong_tieu_thu} Wh")
