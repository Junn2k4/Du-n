class HinhTru:
  def __init__(self, ten, duong_kinh, do_cao):
    self.ten = ten
    self.duong_kinh = duong_kinh
    self.do_cao = do_cao

  def dien_tich_xung_quanh(self):
    chu_vi_day = 3.14 * self.duong_kinh
    return chu_vi_day * self.do_cao

  def the_tich(self):
    ban_kinh = self.duong_kinh / 2
    return 3.14 * (ban_kinh ** 2) * self.do_cao


# Nhập danh sách hình trụ
n = int(input("Nhập số lượng hình trụ: "))
danh_sach_hinh_tru = []
for i in range(n):
  ten = input(f"Nhập tên hình trụ {i + 1}: ")
  duong_kinh = float(input(f"Nhập đường kính hình trụ {i + 1}: "))
  do_cao = float(input(f"Nhập độ cao hình trụ {i + 1}: "))
  hinh_tru = HinhTru(ten, duong_kinh, do_cao)
  danh_sach_hinh_tru.append(hinh_tru)

# In danh sách
print("\nDanh sách hình trụ:")
for hinh_tru in danh_sach_hinh_tru:
  print(f"{hinh_tru.ten}: Đường kính = {hinh_tru.duong_kinh}, Độ cao = {hinh_tru.do_cao}")

# Tìm hình trụ có thể tích lớn nhất và nhỏ nhất
hinh_tru_max = max(danh_sach_hinh_tru, key=lambda x: x.the_tich())
hinh_tru_min = min(danh_sach_hinh_tru, key=lambda x: x.the_tich())
print(f"\nHình trụ có thể tích lớn nhất: {hinh_tru_max.ten} với thể tích {hinh_tru_max.the_tich()}")
print(f"Hình trụ có thể tích nhỏ nhất: {hinh_tru_min.ten} với thể tích {hinh_tru_min.the_tich()}")

# Tính tổng diện tích xung quanh các hình trụ
tong_dien_tich_xung_quanh = sum(hinh_tru.dien_tich_xung_quanh() for hinh_tru in danh_sach_hinh_tru)
print(f"\nTổng diện tích xung quanh các hình trụ: {tong_dien_tich_xung_quanh:.2f}")
