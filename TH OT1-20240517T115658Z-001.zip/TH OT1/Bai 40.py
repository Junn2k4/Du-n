class linh_kien:
  def __init__(self, ten, gia, trang_thai):
    self.ten = ten
    self.gia = gia
    self.trang_thai = trang_thai

  def gia_thuc(self):
    if self.trang_thai == 'hong':
      return self.gia * 0
    if self.trang_thai == 'cu':
      return self.gia / 2
    if self.trang_thai == 'moi':
      return self.gia


while 1:
  try:
    n = int(input("có bnh linh kiện?\n trả lời: "))
    if n <= 0:
      print("nhập lại")
    else:
      break
  except ValueError:
    print("nhập lại")


def nhap_du_lieu(n):
  a = ['hong', 'cu', 'moi']
  ds = []
  for i in range(n):
    print(f"linh kiện {i + 1}: ")
    ten = input("tên : ")
    while 1:
      try:
        gia = float(input("giá thành 1 sp = "))
        trang_thai = input("trạng thái = ")
        if gia > 0 and trang_thai in a:
          ds.append(linh_kien(ten, gia, trang_thai))
          break
        else:
          print("nhập lại")
      except ValueError:
        print("nhập lại")
  return ds


def inn(ds):
  for i, s in enumerate(ds):
    print(f"{i + 1}, {s.ten}: giá = {s.gia}, trạng thái = {s.trang_thai}"
          f"\n=>giá trị thực: {s.gia_thuc()}")


ds = nhap_du_lieu(n)
print("*    ds các linh kiện vừa nhập là: ")
inn(ds)

dem_hong = sum(1 for i in ds if i.trang_thai == 'hong')
ds_lk_hong = [i.ten for i in ds if i.trang_thai == 'hong']
print(f"*   có {dem_hong} linh kiện bị hỏng")

if not ds_lk_hong:
  print("không có lk hỏng")
else:
  print(f"các linh kiện bị hỏng là: {ds_lk_hong}")

ds_lk_moi = [i.ten for i in ds if i.trang_thai == 'moi']
if not ds_lk_moi:
  print("không có lk mới")
else:
  print(f"tuple các linh kiện mới là: {tuple(ds_lk_moi)}")