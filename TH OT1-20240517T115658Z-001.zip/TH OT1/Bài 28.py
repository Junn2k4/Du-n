"""
Tạo 1 class học sinh gồm các thuộc tính: Tên, mã sinh viên, điểm toán, điểm lý,
điểm hóa 
Phương thức tính điểm trung bình 
- Nhập 1 list gồm n học sinh   
- In danh sách sinh viên vừa nhập 
- Tách danh sách trên thành 2 danh sách con:
1 chứa học sinh có điểm trung bình >=5 và 
1 danh sách chứa các học sinh có điểm TB <5
- Tính điểm trung bình từng môn của cả danh sách đã nhập"""
class sinhvien:
    def __init__(self,ten,msv,toan,ly,hoa):
        self.ten=ten
        self.msv=msv
        self.toan=toan
        self.ly=ly
        self.hoa=hoa
    def diemtb(self):
        return round((self.toan+self.ly+self.hoa)/3,2)
def ktten():
    while True:
            ten=input("Nhap ten sinh vien ")
            tach_ten=ten.split()
            if all(i.isalpha() for i in tach_ten):
                return ten
            else:
                print("Ten khong duoc chua so hoac ki tu khac")
def nhap(n):
    ds=[]
    for i in range(n):
        print(f"Nhap thong tin sinh vien thu {i+1}")
        while True:
            try:
                ten=ktten()
                msv=str(input("Nhap ma sinh vien "))
                toan=float(input("Nhap diem toan "))
                ly=float(input("Nhap diem ly "))
                hoa=float(input("Nhap diem hoa "))
                if toan<0 or ly<0 or hoa <0:
                    print("nhap lai")
                else:
                    sv=sinhvien(ten,msv,toan,ly,hoa)
                    ds.append(sv)
                    break
            except ValueError:
                print("Nhap lai")
    return ds
def inra(n):
    if not n:
        print('Khong co danh sach nao vua nhap')
    else:
        for i,s in enumerate(n):
            print(f"Thong tin sinh vien thu{i+1},ten={s.ten},msv={s.msv},toan={s.toan},ly={s.ly}, hoa={s.hoa}, diem tb={s.diemtb()}")
while True:
    try:
        n=int(input("Nhap so luong sinh vien."))
        if n<0:
            print("Nhap so duong: ")
        else:
            break
    except ValueError:
        print("nhap lai!!!")

def tachbe(n):
    tach=list(i for i in n if i.diemtb()<=5)
    return tach
def tachlon(n):
    tachlon=list(i for i in n if i.diemtb()>5)
    return tachlon
def tinhtb(n):
    
    tach_toan=[]
    tach_ly=[]
    tach_hoa=[]
    for i in n:
        tach_hoa.append(i.hoa)
        tach_ly.append(i.ly)
        tach_toan.append(i.toan)
    tb_toan=sum(tuple(tach_toan))/len(tach_toan)
    tb_ly=sum(tuple(tach_ly))/len(tach_ly)    
    tb_hoa=sum(tuple(tach_hoa))/len(tach_hoa) 
    return tb_toan,tb_hoa,tb_ly
ds=nhap(n)
inra(ds)
tachdtbinhbe=tachbe(ds)
tachdtbinhlon=tachlon(ds)
for i in tachdtbinhbe:
    print(f"Thong tin sinh vien do la,ten={i.ten},msv={i.msv},toan={i.toan},ly={i.ly}, hoa={i.hoa}, diem tb={i.diemtb()}")
for i in tachdtbinhlon:
    print(f"Thong tin sinh vien do la,ten={i.ten},msv={i.msv},toan={i.toan},ly={i.ly}, hoa={i.hoa}, diem tb={i.diemtb()}")
tinhtbinh=tinhtb(ds)
print("Diem trung binh tung mon la:",tinhtbinh)