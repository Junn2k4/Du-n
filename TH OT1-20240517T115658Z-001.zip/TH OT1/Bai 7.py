class TGD:
    def __init__(self,a):
        self.a = a
    def cvi(self):
        return self.a*3
    def dtich(self):
        return self.a**2*3**0.5/4
    def cao(self):
        return 3**0.5*self.a/2

def nhap(n):
    d=[]
    for i in range(n):
        print(f'Hình tam giác đều thứ {i+1}:')
        while 1:
            try:
                a=float(input('Nhập cạnh a: '))
                
                if a<=0:
                    print('Nhập lại!')
                else:
                    d.append(TGD(a))
                    break
            except ValueError:
                    print('Nhập lại!')
    return d
def cvmin(ds):
    m=float('inf')
    d=1
    for i in ds:
        if i.cvi()<m:
            m=i.cvi()
            v=d
        d+=1
    return v
def tong(ds):
    t=0
    for i in ds:
        t+=i.dtich()
    return t
def indulieu(a):
    d=0
    for i in a:
        print(f'Hình tam giác đều thứ {d+1}:')
        print(f' Đường cao: {i.cao():.2f}')
        print(f' Chu vi: {i.cvi():.2f}')
        print(f' Diện tích: {i.dtich():.2f}')
        
        d+=1
        
    print(f'Tổng diện tích của n tam giác: {tong(a):.2f}')
    print(f'Hình thứ {cvmin(a)} có chu vi nhỏ nhất')
while 1:
    try:
        n=int(input('Nhập số lượng tam giác đều: '))
        if n<1:
            print('Nhập lại!')
        else:
            break
    except ValueError:
        print('Nhập lại!')

a=nhap(n)
indulieu(a)