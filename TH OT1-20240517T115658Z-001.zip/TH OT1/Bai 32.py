class Robocon:
    diemtd=100
    def __init__(self,tendoi,sodiem,tg)
        self.tendoi=tendoi
        self.sodiem=sodiem
        self.tg=tg
    def tbdiem(self):
        return (self.sodiem/self.tg)*10
def nhap(n):
    ds=[]
    for i in range(n):
        print(f"Nhap doi thi thu {i+1}")
        while True:
            try:
                tendoi=input("Nhap ten doi")
                sodiem=float(input("so diem"))
                tg=float(input("nhap tg"))
            except ValueError:
                print("nhap lai")
def inra(n):
    if not n:
        print("nhap Lai")
    else:
        print("ds nhap la:")
        for i,s in enumerate(n):
            print(f"danh sach doi thu{i+1}")
            print(f" ten doi={s.tendoi}")
"""
class RoboconTeam:
    absolute_score = 100  # Điểm tuyệt đối mặc định

    def __init__(self, team_name, score, match_time):
        self.team_name = team_name
        self.score = score
        self.match_time = match_time

    def avg_score_in_10s(self):
        return (self.score / self.match_time) * 10

def input_teams(n):
    teams = []
    for i in range(n):
        team_name = input("Nhập tên đội thứ {}: ".format(i + 1))
        score = int(input("Nhập số điểm ghi được của đội {}: ".format(team_name)))
        match_time = float(input("Nhập thời gian thi đấu (tối đa 3 phút) của đội {}: ".format(team_name)))
        teams.append(RoboconTeam(team_name, score, match_time))
    return teams

def print_teams(teams):
    print("\nDanh sách đội Robocon:")
    for i, team in enumerate(teams, 1):
        print("{}. Tên đội: {}, Điểm ghi được: {}, Thời gian thi đấu: {} phút".format(i, team.team_name, team.score, team.match_time))

def count_absolute_score_teams(teams):
    absolute_score_teams = [team for team in teams if team.score == RoboconTeam.absolute_score]
    print("\nCó {} đội ghi được điểm tuyệt đối ({} điểm):".format(len(absolute_score_teams), RoboconTeam.absolute_score))
    for team in absolute_score_teams:
        print("- {}".format(team.team_name))

def sort_teams_by_avg_score(teams):
    teams.sort( key=lambda x: x.avg_score_in_10s(), reverse=True)
    print("\nDanh sách đội Robocon sau khi sắp xếp theo điểm TB ghi được trong 10 giây:")
    for i in teams:
        print(f" Ten doi={i.team_name} diem tb={i.avg_score_in_10s()}")

# Nhập thông tin đội Robocon
while True:
    try:
        n = int(input("Nhap so so kiem tra: "))
        if n <= 0:
            print("Nhap lai so duong")
        else:
            break
    except ValueError:
        print("Nhap lai")
teams = input_teams(n)
sort_teams_by_avg_score(teams)
# In danh sách đội Robocon
print_teams(teams)

# Đếm số đội ghi được điểm tuyệt đối và in ra
count_absolute_score_teams(teams)

# Sắp xếp danh sách theo thứ tự giảm dần của điểm TB ghi được trong 10s và in ra
sort_teams_by_avg_score(teams)

"""