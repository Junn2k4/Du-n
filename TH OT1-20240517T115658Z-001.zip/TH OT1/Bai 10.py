class sinhvien:
    def __init__(self,ten,namsinh,toan,van,anh):
        self.ten=ten
        self.namsinh=namsinh
        self.toan=toan
        self.van=van
        self.anh=anh
    def tuoi(self):
        tuoi=2024-self.namsinh
        return tuoi
    def tongdiem(self):
        return (self.toan+self.van+self.anh)
def nhapthongtin(n):
    danhsach=[]
    for i in range(n):
        print(f"nhap thi sinh thu {i+1}")
        while True:
            try:
                ten=str(input("nhap ten thi sinh: "))
                namsinh=int(input("Nhap nam sinh thi sinh: "))
                toan=float(input("Nhap diem toan: "))
                van=float(input("Nhap diem van: "))
                anh=float(input("Nhap diem anh: "))
                if (namsinh<=0 or van< 0 or toan <0 or anh<0):
                    print ("nhap lai")
                else:
                    ts=sinhvien(ten,namsinh,toan,van,anh)
                    danhsach.append(ts)
                    break
            except ValueError:
                print("nhap lai")
    return danhsach
def inthongtin(n):
    if not n:
        print("nhap lai")
    else:
        print("Cac thi sinh vua nhap la: ")
        dem=0
        for i in n:
            dem+=1
            print(f"thi sinh thu {dem+1}: ten={i.ten}, namsinh={i.namsinh}, tuoi={i.tuoi()}")
            print(f"DIEM THI SINH THU {dem+1}: toan={i.toan}, van={i.van},anh={i.anh}, tong diem={i.tongdiem()}")
def tuoimin(n):
    a=n[0].tuoi()
    for i in n:
        if i.tuoi()<a:
            a=i.tuoi()
    return a
def nguoimin(n):
    nguoi=[]
    for i,s in enumerate(n):
        if s.tuoi()==tuoimin(n):
            nguoi.append(i+1)
    return nguoi
def toanmax(n):
    b=n[0].toan
    for i in n:
        if i.toan>b:
            b=i.toan
    return b
def nguoimax(n):
    nguoi1=[]
    for i,s in enumerate(n):
        if s.toan==toanmax(n):
            nguoi1.append(i+1)
    return nguoi1
while True:
    try:
        n=int(input("Nhap so luong thi sinh"))
        if n<0:
            print("nhap lai")
        else:
            break
    except ValueError:
        print("nhap lai")
ds=nhapthongtin(n)
inthongtin(ds)
print("sinh vien co tuoi be nhat la: ",nguoimin(ds))
print("sinh vien co diem toan lon nhat la: ",nguoimax(ds))