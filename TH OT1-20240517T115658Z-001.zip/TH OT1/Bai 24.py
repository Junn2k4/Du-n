class giaithua:
  def __init__(self,n):
    self.n = n
  def tinh_gt(self):
    gt = 1
    if self.n < 0:
      return "ko co gt"
    elif self.n == 0 or self.n == 1:
      return gt
    else:
      for i in range(2, self.n + 1):
        gt = gt * i
      return gt
  def tinh_tong(self):
    if self.n<=0:
      return 0
    else:
      sum = 0
      for i in range(n+1):
        sum += i
      return sum
x=int(input("Nhập số lượng phần tử: "))
while(x<=0):
  x=int(input("Hãy nhập lại số lg pt: "))
  continue
ds=[]
list=[]
list1=[]
for i in range(x):
  n = int(input("Số nguyên thứ %d: " %(i+1)))
  ob = giaithua(n)
  ds.append(ob)
  list.append(ob.tinh_tong())
  list1.append(ob.tinh_gt())
dic={}
for i in range(3):
  dic[ds[i].n]=giaithua(ds[i].n).tinh_gt()
print(dic)
print("Tổng các số từ 1 đến các số vừa nhập là: ",list)
tup = tuple(list1)
print("Tuple chua giai thua cua cac so vua nhap la:",tup)