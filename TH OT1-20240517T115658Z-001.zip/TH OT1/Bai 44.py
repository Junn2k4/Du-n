class KhachHang:
  def __init__(self, ten, st, ls, tg):
    self.ten = ten
    self.st = st
    self.ls = ls
    self.tg = tg

  def so_tien_dc_rut(self):
    return self.st * (1 + self.ls / 100 * self.tg)


def in_ds(ds):
  for i in ds:
    print(f"Ten khach hang: {i.ten}\nSo tien gui: {i.st} - Lai suat: {i.ls} - Thoi gian: {i.tg}")


def tinh_tong(ds):
  return sum(i.st for i in ds)


def dic_tl(ds):
  tl_kh = {}
  for i in ds:
    tl_kh[i.ten] = i.so_tien_dc_rut()
  return tl_kh


while True:
  try:
    n = int(input("So luong khach hang: "))
    if n > 0:
      break
    else:
      print("vui long nhap lai")
  except ValueError:
    print("vui long nhap lai")
danh_sach = []
for i in range(n):

  ten = input("Ten khach hang: ")
  while True:
    try:
      st = int(input("So tien gui: "))
      ls = float(input("Lai suat(%/thang): "))
      tg = float(input("Thoi gian gui:"))
      if st >= 0 and ls >= 0 and tg >= 0:
        ds = KhachHang(ten, st, ls, tg)
        danh_sach.append(ds)
        break
      else:
        print("Vui long nhap lai")
    except ValueError:
      print("vui long nhap lai")
print("Danh sach khach hang: ")
in_ds(danh_sach)
print("Tong so tien goc cua khach hang: ", tinh_tong(danh_sach))
print("Dictionary")
dic_rut_tien = dic_tl(danh_sach)
print(dic_rut_tien)