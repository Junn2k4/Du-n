class DienThoai:
  def __init__(self, ten, he_dieu_hanh, don_gia, so_luong):
    self.ten = ten
    self.he_dieu_hanh = he_dieu_hanh
    self.don_gia = don_gia
    self.so_luong = so_luong

  def tinh_tien(self):
    return self.don_gia * self.so_luong


# Nhập danh sách điện thoại
n = int(input("Nhập số lượng điện thoại: "))
danh_sach_dien_thoai = []
for i in range(n):
  ten = input(f"Nhập tên điện thoại thứ {i + 1}: ")
  he_dieu_hanh = input(f"Nhập hệ điều hành cho {ten}: ")
  don_gia = float(input(f"Nhập đơn giá (đồng) cho {ten}: "))
  so_luong = int(input(f"Nhập số lượng cho {ten}: "))
  dien_thoai = DienThoai(ten, he_dieu_hanh, don_gia, so_luong)
  danh_sach_dien_thoai.append(dien_thoai)

# In danh sách vừa nhập
print("\nDanh sách điện thoại:")
for dt in danh_sach_dien_thoai:
  print(f"{dt.ten}: Hệ điều hành = {dt.he_dieu_hanh}, Đơn giá = {dt.don_gia} đồng, Số lượng = {dt.so_luong}")

# Tạo tuple chứa các điện thoại dùng hệ điều hành Android
dien_thoai_android = tuple(filter(lambda dt: dt.he_dieu_hanh.lower() == "android", danh_sach_dien_thoai))
print("\nCác điện thoại dùng hệ điều hành Android:")
for dt in dien_thoai_android:
  print(f"{dt.ten}")

# Đếm số lượng điện thoại có số lượng = 0 và xóa khỏi danh sách
so_luong_0 = 0
for dt in danh_sach_dien_thoai:
  if dt.so_luong == 0:
    so_luong_0 += 1
    danh_sach_dien_thoai.remove(dt)

print(f"\nSố lượng điện thoại có số lượng = 0: {so_luong_0}")
print("Danh sách sau khi xóa:")
for dt in danh_sach_dien_thoai:
  print(f"{dt.ten}: Số lượng = {dt.so_luong}")
