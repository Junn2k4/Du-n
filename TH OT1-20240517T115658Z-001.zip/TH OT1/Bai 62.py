class SinhVien:
  def __init__(self, ten, diem_tich_luy, tin_chi_no):
    self.ten = ten
    self.diem_tich_luy = diem_tich_luy
    self.tin_chi_no = tin_chi_no

  def xac_dinh_tinh_trang_hoc(self):
    if self.diem_tich_luy < 0.8 or self.tin_chi_no > 20:
      return "Đuổi học"
    elif 0.8 <= self.diem_tich_luy <= 1.0 and self.tin_chi_no <= 20:
      return "Cảnh cáo"
    else:
      return "Tiếp tục học"


# Nhập danh sách sinh viên
n = int(input("Nhập số lượng sinh viên: "))
danh_sach_sinh_vien = []
for i in range(n):
  ten = input(f"Nhập tên sinh viên {i + 1}: ")
  diem_tich_luy = float(input(f"Nhập điểm tích lũy của {ten}: "))
  tin_chi_no = int(input(f"Nhập số tín chỉ nợ của {ten}: "))
  sv = SinhVien(ten, diem_tich_luy, tin_chi_no)
  danh_sach_sinh_vien.append(sv)

# In danh sách sinh viên
print("\nDanh sách sinh viên:")
for sv in danh_sach_sinh_vien:
  print(f"{sv.ten}: Điểm tích lũy {sv.diem_tich_luy:.2f}, Tín chỉ nợ {sv.tin_chi_no}")

# Tạo dictionary với key là tên sv, value là trạng thái học
trang_thai_sv = {}
for sv in danh_sach_sinh_vien:
  trang_thai_sv[sv.ten] = sv.xac_dinh_tinh_trang_hoc()

# Sắp xếp danh sách theo thứ tự giảm dần của điểm tích lũy
danh_sach_sinh_vien.sort(key=lambda x: x.diem_tich_luy, reverse=True)

print("\nTrạng thái học của sinh viên:")
for ten, trang_thai in trang_thai_sv.items():
  print(f"{ten}: {trang_thai}")
