class MachLC:
  def __init__(self, ten, L, C):
    self.ten = ten
    self.L = L
    self.C = C

  def tanso(self):
    return 1 / (2 * 3.14 * (self.L * self.C) ** 0.5)


def kiemthu(n):
  while True:
    try:
      gtr = float(input(n))
      if gtr <= 0:
        print("Giá trị cần nhập lớn hơn 0")
      else:
        return gtr
    except:
      print("Nhập giá trị là số")


ds = []
n = int(input("Nhập số lượng các mạch LC: "))
for i in range(n):
  print(f"Nhập thông tin mạch thứ {i + 1}")
  ten = input("Nhập tên mạch: ")
  L = kiemthu("Nhập giá trị cuả L: ")
  C = kiemthu("Nhập giá trị của C: ")
  mach = MachLC(ten, L, C)
  ds.append(mach)
print('Danh sách vừa nhập là:')
for i in ds:
  print(f'Mạch {i.ten} có tần số= {i.tanso()}')
ds.sort(key=lambda x: x.tanso(), reverse=True)
print(f'danh sách mạch theo thứ tự giảm dần của tần số:')
for i in ds:
  print(f'Mạch {i.ten} có tần số = {i.tanso()}')
machmax = max(ds, key=lambda x: x.tanso())
print(f'=> Mạch {machmax.ten} có tần số lớn nhất ({machmax.tanso()})')