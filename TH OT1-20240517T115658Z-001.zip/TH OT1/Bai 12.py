from math import*
class So:
    def __init__(self,a):
        self.a = a
    def ktcp(self):
        if self.a<0: 
            return 0
        else:
            return isqrt(self.a)==sqrt(self.a)
    def ktnt(self):
        if self.a<2:
            return 0
        else:
            k=1
            for i in range(2,self.a//2+1):
                if self.a%i==0:
                    k=0
                    break
            return k
    def ktcl(self):
        return self.a%2==0
    
def nhap(n):
    d=[]
    for i in range(n):
        while 1:
            try:
                val=int(input(f'Nhập số thứ {i+1}: '))
                d.append(So(val))
                break
            except ValueError:
                print('Nhập số nguyên')
    return d

def tich(ds):
    t=1
    for i in ds:
        if i.ktnt():
            t*=i.a
    return t
def cpm(ds):

    for i in ds:
        if i.ktcp():
            m=i.a
            break
    for i in ds:
        if i.ktcp():
            if i.a<m:
                m=i.a
    return m
def indl(ds):
    b=[]
    
    
    for i in ds:
        if not i.ktcl():
            b.append(i.a)
    if not b:
        print('Không có số lẻ nào')
    else:
        print(f'Các số lẻ là: {b}')
    if not tich(ds):
        print('Không có số nguyên tố nào!')
    else:
        print(f'Tích các số nguyên tố: {tich(ds)}')
    if not cpm(ds):
        print ('Không có số chính phương')
    else:
        print(f'Số nguyên chính phương nhỏ nhất: {cpm(ds)}')
    
while 1:
    try:
        n=int(input('Nhập số lượng các số: '))
        if n<1:
            print('Nhập lại!')
        else:
            break
    except ValueError:
        print('Nhập lại!')

ds=nhap(n)
indl(ds)