class songuyen:
    def __init__(self,b):
        self.b=b
    def ktad(self):
        if self.b <0:
            return 1
        else:
            return 0
    def ktdx(self):
        if self.b<10:
            return 0
        else:
            str_a=str(self.b)
            return str_a==str_a[::-1]
    def ktht(self):
        sum=0
        for i in range(1, self.b):
            if (self.b%i==0):
                sum+=i
        if sum==self.b:
            return 1
        else:
            return 0
def nhapso(n):
    lis_so=[]
    lis_am=[]
    lis_dx=[]
    lis_ht=[]
    for i in range (n):
        print(f'Nhap so thu {i+1}')
        while True:
            try:
                a=int(input("Nhap so: "))
                so=songuyen(a)
                lis_so.append(so)
                if so.ktad() == 1:
                    lis_am.append(so.b)
                if so.ktdx() == 1:
                    lis_dx.append(so.b)
                if so.ktht() == 1:
                    lis_ht.append(so.b)
                break
            except ValueError:
                print("Nhap Lai. ")
    return lis_so,lis_am,lis_dx,lis_ht
def inso(day,am,doixung,hoanthien):
    if not day:
        print("khong co day nao")
    else: 
        if not am:
            print("Khong co so am trong day")
        else:
            print(f"So am trong day la: {am}")
        if not doixung:
            print("Khong co so doi xung")
        else:
            tong=0
            for i in doixung:
                tong+=i
            print(f"tong cac so doi xung la{tong}")
        if not hoanthien:
            print("khong co so hoan thien")
        else:
            print(f"so hoan thien {hoanthien}")
def maxcp(n):
    maxcpt=n[0]
    for i in range(n):
        if i>maxcpt:
            maxcpt=i
    return maxcpt
while True:
    try:
        n=int(input("Nhap so luong day: "))
        day,am,doixung,hoanthien=nhapso(n)
        if n<0:
            print("nhap lai")
        else:
            inso(day,am,doixung,hoanthien)
            break
    except ValueError:
        print("nhap lai")