class MayTinh:
  def __init__(self, ten_may, thoi_gian_su_dung, tinh_trang):
    self.ten_may = ten_may
    self.thoi_gian_su_dung = thoi_gian_su_dung
    self.tinh_trang = tinh_trang

  def co_thanh_ly(self):
    if self.tinh_trang == 'hỏng' or self.thoi_gian_su_dung >= 3:
      return True
    elif self.thoi_gian_su_dung >= 5:
      return True
    else:
      return False


def in_danh_sach_may_tinh(danh_sach):
  print("Danh sách máy tính:")
  for may_tinh in danh_sach:
    print(
      f"Tên máy: {may_tinh.ten_may}, Thời gian sử dụng: {may_tinh.thoi_gian_su_dung} năm, Tình trạng: {may_tinh.tinh_trang}")


def tao_tuple_may_thanh_ly(danh_sach):
  danh_sach_thanh_ly = [may_tinh for may_tinh in danh_sach if may_tinh.co_thanh_ly()]
  return tuple(danh_sach_thanh_ly)


def dem_va_xoa_thanh_ly(danh_sach):
  so_may_thanh_ly = sum(1 for may_tinh in danh_sach if may_tinh.co_thanh_ly())
  danh_sach = [may_tinh for may_tinh in danh_sach if not may_tinh.co_thanh_ly()]
  return so_may_thanh_ly, danh_sach


def main():
  # Nhập số lượng máy tính
  n = int(input("Nhập số lượng máy tính: "))

  # Nhập danh sách máy tính
  danh_sach_may_tinh = []
  for i in range(n):
    ten_may = input(f"Nhập tên máy của máy tính thứ {i + 1}: ")
    thoi_gian_su_dung = int(input(f"Nhập thời gian sử dụng (năm) của máy tính thứ {i + 1}: "))
    tinh_trang = input(f"Nhập tình trạng (tốt/hỏng) của máy tính thứ {i + 1}: ")
    danh_sach_may_tinh.append(MayTinh(ten_may, thoi_gian_su_dung, tinh_trang))

  # In danh sách máy tính
  in_danh_sach_may_tinh(danh_sach_may_tinh)

  # Tạo tuple chứa danh sách các máy tính cần thanh lý
  tuple_may_thanh_ly = tao_tuple_may_thanh_ly(danh_sach_may_tinh)
  print("\nTuple chứa danh sách các máy tính cần thanh lý:")
  print(tuple_may_thanh_ly)

  # Đếm và xóa khỏi danh sách các máy tính trong tình trạng thanh lý
  so_may_thanh_ly, danh_sach_may_tinh = dem_va_xoa_thanh_ly(danh_sach_may_tinh)
  print(f"\nSố lượng máy tính cần thanh lý: {so_may_thanh_ly}")
  print("Danh sách máy tính sau khi loại bỏ các máy cần thanh lý:")
  in_danh_sach_may_tinh(danh_sach_may_tinh)


if __name__ == "__main__":
  main()
