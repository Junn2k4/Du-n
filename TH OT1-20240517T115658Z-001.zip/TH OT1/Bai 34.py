"""
- Tạo 1 class nhân viên gồm các thuộc tính: tên nhân viên, số năm công tác, hệ số lương. 
Phương thức tính lương 
- Nhập 1 list gồm n nhân viên  
- In danh sách vừa nhập 
- Sắp xếp danh sách theo thứ tự giảm dần của lương 
- In danh sách những nhân viên đủ điều kiện về hưu (số năm công tác >=25).
"""
class nhanvien:
    def __init__(self,tennv,snam,hsl):
        self.tennv=tennv
        self.snam=snam
        self.hsl=hsl
    def tinhluong(self):
        return self.hsl*self.snam
while True:
    try:
        n=int(input("Nhap so nhan vien."))
        if n<0:
            print("Nhap so duong: ")
        else:
            break
    except ValueError:
        print("nhap lai!!!")
def kiemtra():
    while True:
        a=input("nhap ten nv: ")
        tach=a.split()
        if all(i.isalpha() for i in tach):
            return a
        else:
            print("ten k dc co so va ki tu")
def nhap(n):
    dsach=[]
    for i in range(n):
        print(f"nhap nhan vien thu {i+1}")
        while True:
            try:
                a= kiemtra()
                b=float(input("nhap so nam: "))
                c=float(input("nhap hs luong: "))
                if (b<=0 or c<=0 ):
                    print("Nhap cac so duong")
                else:
                    tg=nhanvien(a,b,c)
                    dsach.append(tg)
                    break
            except ValueError:
                print("nhap lai. ")
    return dsach
def inra(ds):
    if not ds:
        print("khong co danh sach nao")
    else:
        print("cac nhan vien la:")
        dem=0
        for i in ds:
            dem+=1
            print(f"nhan vien thu {dem} , Ten={i.tennv},So nam={i.snam},hsl={i.hsl}, luong ={i.tinhluong()}")
def sapxep(n):
    sap =sorted(n, key=lambda x:x.tinhluong(), reverse = True)
    return sap
def saphuu(n):
    luonghuu=list(i for i in n if i.snam>=25)
    return luonghuu
ds=nhap(n)
inra(ds)
giam=sapxep(ds)
dem1=0
print("sap xep la: ")
for i in giam:
    dem1+=1
    print(f"nhan vien thu {dem1} , Ten={i.tennv},So nam={i.snam},hsl={i.hsl}, luong ={i.tinhluong()}")
huu=saphuu(ds)
dem2=0
print("danh sach nhan vien du dk ve huu la ")
if not huu:
    print("Khong co")
else:
    for i in huu:
        dem2+=1
        print(f"nhan vien thu {dem2} , Ten ={i.tennv},so nam={i.snam},hsl={i.hsl}, luong ={i.tinhluong()}")
