class tugiac:
    def __init__(self,a,b):
        self.a=a
        self.b=b
    def chuvi(self):
        return 2*(self.a+self.b)
    def dientich(self):
        return self.a*self.b
    def duongcheo(self):
        return int((self.a**2+self.b**2)**0.5)
def nhapcanh(n):
    dsach=[]
    for i in range(n):
        print(f"nhap hinh chu nhat thu {i+1}")
        while True:
            try:
                a=float(input("nhap canh thu 1: "))
                b=float(input("nhap canh thu 2: "))
                if (a<=0 or b<=0):
                    print("Nhap cac so duong")
                else:
                    tg=tugiac(a,b)
                    dsach.append(tg)
                    break
            except ValueError:
                print("nhap lai. ")
    return dsach
def inhinh(n):
    if not n:
        print("khong co danh sach nao")
    else:
        print("cac hinh tu giac la:")
        dem=0
        for i in n:
            dem+=1
            print(f"hinh tu giac {dem} , a={i.a},b={i.b}, chuvi={i.chuvi()},duongcheo={i.duongcheo()},dientich={i.dientich()}")
def tdientic(n):
    tong=0
    for i in n:
        tong+=i.dientich()
    return tong
def dcmin(n):
    a=n[0].chuvi()
    for i in n:
        if i.chuvi()<a:
            a=i.chuvi()
    return a
def timhinh(n):
    hinh=[]
    for i,s in enumerate(n):
        if s.chuvi()==dcmin(n):
            hinh.append(i+1)
    return hinh
while True:
    try:
        n=int(input("nhap so luong hinh "))
        if n<0:
            print("Nhap cac so duong. ")
        else:
            break
    except ValueError:
        print("Nhap lai")
ds=nhapcanh(n)
inhinh(ds)
print("tong dien tich cua cac hinh chu nhat la: ",tdientic(ds))
print("Hinh co duong cheo min",timhinh(ds))