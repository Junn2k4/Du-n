class NhanVien:
    def __init__(self, ho_ten, so_nam_cong_tac, luong_co_ban, he_so_luong):
        self.ho_ten = ho_ten
        self.so_nam_cong_tac = so_nam_cong_tac
        self.luong_co_ban = luong_co_ban
        self.he_so_luong = he_so_luong

    def tinh_luong(self):
        return self.luong_co_ban * self.he_so_luong + self.so_nam_cong_tac * 0.1 * self.luong_co_ban
def kiemtra(name):
    return name.replace(" ", "").isalpha()
def nhap_nhan_vien(n):
    danh_sach_nhan_vien = []
    for i in range(n):
        print(f'Nhập thông tin nhân viên thứ {i+1}:')
        while True:
            ho_ten = input('Họ tên: ')
            if kiemtra(ho_ten):
                break
            else:
                print("Tên không hợp lệ, vui lòng chỉ nhập chữ cái và khoảng trắng.")
            so_nam_cong_tac = int(input('Số năm công tác: '))
            if kiemtra(so_nam_cong_tac):
                break
            else:
                print("Tên không hợp lệ, vui lòng chỉ nhập chữ cái và khoảng trắng.")
            luong_co_ban = float(input('Lương cơ bản: '))
            if kiemtra(luong_co_ban):
                break
            else:
                print("Tên không hợp lệ, vui lòng chỉ nhập chữ cái và khoảng trắng.")
        he_so_luong = float(input('Hệ số lương: '))
        nhan_vien = NhanVien(ho_ten, so_nam_cong_tac, luong_co_ban, he_so_luong)
        danh_sach_nhan_vien.append(nhan_vien)
    return danh_sach_nhan_vien

def in_danh_sach_nhan_vien(danh_sach_nhan_vien):
    for nv in danh_sach_nhan_vien:
        print(f'Họ tên: {nv.ho_ten}, Số năm công tác: {nv.so_nam_cong_tac}, Lương cơ bản: {nv.luong_co_ban}, Hệ số lương: {nv.he_so_luong}, Lương: {nv.tinh_luong()}')

def tim_nhan_vien_nhieu_nam_cong_tac_nhat(danh_sach_nhan_vien):
    max_nam_cong_tac = max(nv.so_nam_cong_tac for nv in danh_sach_nhan_vien)
    return [nv for nv in danh_sach_nhan_vien if nv.so_nam_cong_tac == max_nam_cong_tac]

def tinh_tong_luong(danh_sach_nhan_vien):
    return sum(nv.tinh_luong() for nv in danh_sach_nhan_vien)

# Sử dụng các hàm đã định nghĩa
n = int(input('Nhập số lượng nhân viên: '))
danh_sach_nhan_vien = nhap_nhan_vien(n)
in_danh_sach_nhan_vien(danh_sach_nhan_vien)
nhan_vien_nhieu_nam_cong_tac_nhat = tim_nhan_vien_nhieu_nam_cong_tac_nhat(danh_sach_nhan_vien)
print('Nhân viên có số năm công tác nhiều nhất:')
for nv in nhan_vien_nhieu_nam_cong_tac_nhat:
    print(f'Họ tên: {nv.ho_ten}, Số năm công tác: {nv.so_nam_cong_tac}')
tong_luong = tinh_tong_luong(danh_sach_nhan_vien)
print(f'Tổng lương của tất cả nhân viên: {tong_luong}')
